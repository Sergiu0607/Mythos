# Bytecode module
